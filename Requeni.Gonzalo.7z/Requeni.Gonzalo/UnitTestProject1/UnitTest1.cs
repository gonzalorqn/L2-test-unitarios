using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Entidades.Estacionamientos.starter;

namespace UnitTestProject1
{
  [TestClass]
  public class UnitTest1
  {
        [TestMethod]
        public void ListaNoNula()
        {
            Estacionamiento e = new Estacionamiento(10);

            Assert.IsNotNull(e.Autos);
        }

        [TestMethod]
        public void EspacioEstacionamientoIncorrecto()
        {
            Estacionamiento e = new Estacionamiento(101);

            if(e.EspacioDisponible != 101)
            {
                Assert.Fail("Espacio incorrecto 101 != {0}", e.EspacioDisponible);
            }

            Estacionamiento e2 = new Estacionamiento(0);

            Assert.AreNotEqual(e2.EspacioDisponible,1);

            if (e2.EspacioDisponible != 0)
            {
                Assert.Fail("Espacio incorrecto 0 != {0}", e2.EspacioDisponible);
            }
        }

        [TestMethod]
        public void AgregarAutosEstacionamiento()
        {
            Estacionamiento e = new Estacionamiento(2);
            Auto a1 = new Auto("ASD 123", ConsoleColor.Blue);
            Auto a2 = new Auto("DJA 585", ConsoleColor.Black);
            Auto a3 = new Auto("AAA 000", ConsoleColor.Red);

            try
            {
                e += a1;
                e += a2;
                e += a3;
                Assert.Fail("Error de validacion de espacio");
            }
            catch(Exception exception)
            {
                Assert.IsInstanceOfType(exception, typeof (EstacionamientoLlenoException));
            }
        }

        [TestMethod]
        public void AgregarAutoEspacioDisponible()
        {
            Estacionamiento e = new Estacionamiento(2);
            Auto a1 = new Auto("ASD 123", ConsoleColor.Blue);
            Auto a2 = new Auto("DJA 585", ConsoleColor.Black);

            e += a1;
            Assert.AreEqual(e.EspacioDisponible, 1);

            e += a2;
            Assert.AreEqual(e.EspacioDisponible, 0);
        }
    }
}
